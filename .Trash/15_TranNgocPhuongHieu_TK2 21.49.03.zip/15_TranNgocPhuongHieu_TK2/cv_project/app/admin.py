from django.contrib import admin
from .models import *

admin.site.register(CV)
admin.site.register(Todo)

# Register your models here.
