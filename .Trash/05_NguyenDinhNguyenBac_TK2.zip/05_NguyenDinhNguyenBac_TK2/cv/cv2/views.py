from django.shortcuts import render

def cv(request):
    return render(request, 'cv2.html', {})